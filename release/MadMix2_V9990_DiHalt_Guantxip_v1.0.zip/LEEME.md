# Mad Mix 2 V9990: DiHalt + Guantxip (v1.0)

Nueva versión de la conversión V9990 de **DiHalt Studio** (github.com/DiHaltStudio/madmix2-v9990, v1.0), hecha con su permiso, con un segundo set gráfico: el de **Guantxip** para el remake V9990.

## Cómo se juega

- ROM `MadMix2_V9990_DiHalt_Guantxip_v1.0.rom` (2 MB, ASCII16). Necesita MSX con cartucho V9990 (GFX9000). openMSX la detecta sola como ASCII16.
- En el menú, arriba/abajo eligen la línea (la activa sale en verde entre < >) e izquierda/derecha cambian su valor:
  - STANDARD / HARD.
  - Set gráfico: GUANTXIP (el de entrada) o DIHALT.
  - ARRIBA IZQDA (como el original: arriba lleva a Pac arriba a la izquierda) o ARRIBA DCHA (arriba lleva arriba a la derecha; todas las direcciones giran 90°, también con Q A O P y joystick).
  - Z80 / R800: solo en un MSX turbo R (en los demás se queda en Z80). Se aplica al empezar la partida, con el mismo método que la BIOS (CHGCPU) y con el piloto R800 encendido. El juego va sincronizado con la imagen, así que el R800 no lo acelera: solo evita ralentizaciones.
- ESPACIO o disparo para jugar.
- H pausa el juego (como en el original); se sigue con ESPACIO o disparo.
- El set se carga al empezar la partida; tras GAME OVER se puede elegir otro. Las opciones se conservan entre partidas (la dificultad vuelve a STANDARD, como en la v1.0).
- Con el set de Guantxip, las fases 4-6 usan su segunda paleta de losetas (familia 1), como en sus hojas.
- Con el set de Guantxip, mientras dura la bola grande Pac sale con sus sprites rojos; en los últimos 30 tics parpadea entre rojo y amarillo, al mismo ritmo que el original.
- Con el set de Guantxip, los mapas llevan sus correcciones de losetas (las de sus imágenes de cada fase, con las losetas nuevas que dibujó). Solo cambia el dibujo: cada loseta nueva conserva la colisión de la que sustituye, y el set DIHALT carga los mapas originales sin tocar. No se aplicaron dos cambios que alterarían el juego: fase 3, 41→38 en 8 casillas (cambia la clase de colisión 7→6) y fase 8, 41→1 en (38,46). Lista completa en `cambios.txt`.
- Correcciones de Guantxip del 11-11 (baldosas de la familia 0, fases 2 y 3): su variante de la baldosa del pie del muro grande, sin la esquina del bloque, va en las diagonales de ese muro en las fases 2 y 3. Como no quedaba ningún número de baldosa libre, la 30 (misma imagen que la 27 en su set) pasa a 27 en sus mapas y la 30 lleva la variante; su máscara de ocupación se carga con el set, así que el set DIHALT sigue igual.
- Corrección de Guantxip del 11-11 (baldosas de la familia 1): la baldosa 8 lleva su dibujo nuevo, que sale en la fase 5 donde él lo pinta; en las demás casillas donde su dibujo de la fase lleva la de antes, va la 27 (misma imagen y misma máscara que la 8 antigua).

## Qué viene de cada uno

- Juego original: Topo Soft, 1990.
- Conversión V9990, motor, música y set DIHALT: DiHalt Studio, 2026.
- Set GUANTXIP (losetas de las dos familias, figuras de paletas 3 y 4, ventana del marcador, cara de las vidas con los dos ojos colocados como los pinta el juego, Pac rojo de la bola grande, correcciones de los mapas): Guantxip. Figuras que Guantxip no dibujó: la pose 5 de Pac sale de su pose 4 estrechada un píxel (como la de Topo), y la sombra grande (pose 20) y las poses 88 y 90 usan la silueta original con sus colores (la sombra con el mismo color que sus otras sombras).
- Opción de set e importación del arte: araubi, desarrollado con Claude (Anthropic).

Créditos en pantalla: «GRAFICOS V9990 / GUANTXIP» bajo los de DiHalt.

Comprobado: compilación con sjasmplus 1.24 idéntica byte a byte a la v1.0 antes de los cambios; partidas en openMSX con los dos sets, fase 4 y cambio de set tras GAME OVER; mapa de la fase 2 en RAM igual al corregido (Guantxip) y al original (DiHalt); Pac rojo y parpadeo.

SHA-1 de la ROM: 66925b713148c9219204e69ea0d3681003c0f41c
